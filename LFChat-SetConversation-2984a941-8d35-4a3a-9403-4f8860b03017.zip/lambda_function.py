import json
import boto3
from botocore.exceptions import ClientError

db = boto3.resource('dynamodb')
conversationsTable = db.Table("Conversations")

def lambda_handler(event, context):
    
    print(event)
    
    try:
        # body = json.loads(event['body'])
        # conversationId = body['conversationId']
        # if "newUpdatedAt" in body:
        #     newUpdatedAt = body["newUpdatedAt"]
        # else:
        #     newUpdatedAt = None
        # if "newLastReadAt" in body:
        #     newLastReadAt = body["newLastReadAt"]
        # else:
        #     newLastReadAt = None
        conversationId = '002'
        newUpdatedAt = "2023-12-17T14:20:28.262Z"
        newLastReadAt = ["2023-12-17T14:20:28.262Z", "2023-12-15T14:20:28.262Z"]
        
        
        if newUpdatedAt:
            update_item({'conversationId':conversationId}, "updatedAt", newUpdatedAt, conversationsTable)
        if newLastReadAt:
            update_item({'conversationId':conversationId}, "lastReadAt", newLastReadAt, conversationsTable)
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': '*',
            },
            'body': json.dumps('Successfully set the updated conversation')
        }
    except Exception as e:
        # Handle any errors and return an error response
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': '*',
            },
            'body': f'Fail to get conversations: {str(e)}'
        }

def lookup_data(key, table):
    try:
        response = table.get_item(Key=key)
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        return response["Item"]
        
def update_item(key, feature, value, table):
    response = table.update_item(
        Key=key,
        UpdateExpression="set #feature=:f",
        ExpressionAttributeValues={
            ':f': value
        },
        ExpressionAttributeNames={
            "#feature": feature
        },
        ReturnValues="UPDATED_NEW"
    )
    print(response)
    return response
