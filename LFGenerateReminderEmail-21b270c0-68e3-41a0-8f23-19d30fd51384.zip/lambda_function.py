import json
import datetime
import boto3
import decimal


# {'treatmentPlan': {'L': [{'M': {'patientEmail': {'S': 'patient1@gmail.com'}, 'TreatmentId': {'N': '1'}, 'Medicines': {'L': [{'M': {'duration': {'N': '4'}, 'current_duration': {'N': '0'}, 'MedicineName': {'S': 'Aspirin1'}, 'quantity': {'N': '1'}, 'lastReminderDateTime': {'S': ''}, 'doctorCreatedBy': {'S': 'doctor1@gmail.com'}, 'location': {'S': 'mouth'}, 'type': {'S': 'capsule'}, 'dateModifed': {'S': '2023-12-19 11:48:53.755424'}, 'frequency': {'S': 'daily'}}}, {'M': {'duration': {'N': '4'}, 'current_duration': {'N': '0'}, 'MedicineName': {'S': 'Aspirin2'}, 'quantity': {'N': '1'}, 'lastReminderDateTime': {'S': ''}, 'doctorCreatedBy': {'S': 'doctor1@gmail.com'}, 'location': {'S': 'mouth'}, 'type': {'S': 'capsule'}, 'dateModifed': {'S': '2023-12-19 11:48:53.755444'}, 'frequency': {'S': 'daily'}}}, {'M': {'duration': {'N': '4'}, 'current_duration': {'N': '0'}, 'MedicineName': {'S': 'Aspirin3'}, 'quantity': {'N': '1'}, 'lastReminderDateTime': {'S': ''}, 'doctorCreatedBy': {'S': 'doctor1@gmail.com'}, 'location': {'S': 'mouth'}, 'type': {'S': 'capsule'}, 'dateModifed': {'S': '2023-12-19 11:48:53.755447'}, 'frequency': {'S': 'daily'}}}, {'M': {'duration': {'N': '4'}, 'current_duration': {'N': '0'}, 'MedicineName': {'S': 'Aspirin4'}, 'quantity': {'N': '1'}, 'lastReminderDateTime': {'S': ''}, 'doctorCreatedBy': {'S': 'doctor1@gmail.com'}, 'location': {'S': 'mouth'}, 'type': {'S': 'capsule'}, 'dateModifed': {'S': '2023-12-19 11:48:53.755450'}, 'frequency': {'S': 'daily'}}}]}, 'enabledReminder': {'BOOL': True}}}]}, 'patientEmail': {'S': 'patient1@gmail.com'}}
# Processing
# {'treatmentPlan': {'L': [{'M': {'TreatmentId': {'N': '15'}, 'Medicines': {'L': [{'M': {'duration': {'N': '4'}, 'location': {'S': 'mouth'}, 'MedicineName': {'S': 'I made a change 3'}, 'quantity': {'N': '2'}, 'type': {'S': 'tablet'}, 'frequency': {'S': 'daily'}}}]}, 'enabledReminder': {'BOOL': False}}}]}, 'patientEmail': {'S': 'patient2@gmail.com'}}



def scan_table(dynamo_client, *, TableName, **kwargs):
    """
    Generates all the items in a DynamoDB table.

    :param dynamo_client: A boto3 client for DynamoDB.
    :param TableName: The name of the table to scan.

    """
    paginator = dynamo_client.get_paginator("scan")

    for page in paginator.paginate(TableName=TableName, ConsistentRead=True, **kwargs):
        yield from page["Items"]

[{'TreatmentId': Decimal('1'), 'Medicines': [{'duration': Decimal('4'), 'current_duration': Decimal('0'), 'MedicineName': 'Aspirin1', 'quantity': Decimal('1'), 'lastReminderDateTime': '', 'doctorCreatedBy': 'doctor1@gmail.com', 'location': 'mouth', 'type': 'capsule', 'dateModifed': '2023-12-19 14:53:12.873049', 'frequency': 'daily'}, {'duration': Decimal('4'), 'current_duration': Decimal('0'), 'MedicineName': 'Aspirin2', 'quantity': Decimal('1'), 'lastReminderDateTime': '', 'doctorCreatedBy': 'doctor1@gmail.com', 'location': 'mouth', 'type': 'capsule', 'dateModifed': '2023-12-19 14:53:12.873076', 'frequency': 'daily'}, {'duration': Decimal('4'), 'current_duration': Decimal('0'), 'MedicineName': 'Aspirin3', 'quantity': Decimal('1'), 'lastReminderDateTime': '', 'doctorCreatedBy': 'doctor1@gmail.com', 'location': 'mouth', 'type': 'capsule', 'dateModifed': '2023-12-19 14:53:12.873079', 'frequency': 'daily'}, {'duration': Decimal('4'), 'current_duration': Decimal('0'), 'MedicineName': 'Aspirin4', 'quantity': Decimal('1'), 'lastReminderDateTime': '', 'doctorCreatedBy': 'doctor1@gmail.com', 'location': 'mouth', 'type': 'capsule', 'dateModifed': '2023-12-19 14:53:12.873082', 'frequency': 'daily'}], 'enabledReminder': True}]


def generateReminder(patientEmail, treatmentPlans):
    if len(treatmentPlan['L']):
        print("No treatments???")
        return None
    else:
        reminders = []
        for treatmentPlanList in treatmentPlans["L"]:
            # Parsing through list of treatment plans
            for treatmentPlanDictionary in treatmentPlanList["M"]:
                #print("Scanning through TreatmentID {} for patient {}".format(treatmentPlanDictionary["TreatmentID"]['N']), patientEmail)
                if treatmentPlanDictionary["enabledReminder"]["BOOL"]:
                    for medicineDictionary in medicinetreatmentPlanDictionary["Medicines"]["L"]:
                        #Has a reminder been generated for it previously?
                        if medicineDictionary["M"]["lastReminderDateTime"]["S"] == "":
                            pass
                        elif medicineDictionary["M"]["lastReminderDateTime"]["S"]
                            
                        frequency = medicineDictionary["M"]["frequency"]["S"]
                        if frequency == "daily" and 
                        ["lastReminderDateTime"]["S"]
                        if medicineDictionary["lastReminderDateTime"]["S"]
                else:
                    return
    
    


def lambda_handler(event, context):
    # TODO implement

    print(response)

    for item in scan_table(dynamo_client, TableName="treatmentPlans"):
        # print("Processing")
        generateReminder(item["patientEmail"]['S'], item["treatmentPlan"])
        # print(json.dumps(item, cls=DecimalEncoder))
        print(item)
    
    
    
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
