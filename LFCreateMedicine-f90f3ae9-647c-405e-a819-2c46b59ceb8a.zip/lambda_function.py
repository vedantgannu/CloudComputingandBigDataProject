import json
import boto3
import botocore
import datetime
from dateutil.relativedelta import relativedelta


"""
Creates a treatment plan for patient and creates future reminders for each medication
Inputs:
    doctorEmail
    patientEmail
    newTreatmentPlan
"""


# patientEmail = "patient1@gmail.com"
# doctorEmail = "doctor1@gmail.com"

# newTreatmentPlan = {
#                     "TreatmentId":1,
#                     "Medicines":[
#                             {"MedicineName":"Aspirin1", "quantity":1, "type": "capsule", 
#                             "location": "mouth", "frequency": "daily", "duration": 4
#                             }, 
#                             {"MedicineName":"Aspirin2", "quantity":1, "type": "capsule", 
#                             "location": "mouth", "frequency": "month", "duration": 4
#                             }, 
#                             # {"MedicineName":"Aspirin3", "quantity":1, "type": "capsule", 
#                             # "location": "mouth", "frequency": "daily", "duration": 4
#                             # }, 
#                             # {"MedicineName":"Aspirin4", "quantity":1, "type": "capsule", 
#                             # "location": "mouth", "frequency": "daily", "duration": 4
#                             # }, 
                            
#                             ],
#                     "enabledReminder":True,
#                     "doctorCreatedBy":"doctor1@gmail.com", 
#                     "dateModifed": "2023-12-15T14:20:28.262Z"
    
# }


def lambda_handler(event, context):
    # TODO implement
    doctorEmail = event["doctorEmail"]
    patientEmail = event["patientEmail"]
    newTreatmentPlan = event["newTreatmentPlan"]
    
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    treatmentPlans_dbtable = dynamodb.Table('treatmentPlans')
    reminders_dbtable = dynamodb.Table('reminders')
    
    try:
        print("Received Create Treatment Plan request")
        print("patientEmail:", patientEmail)
        print("doctorEmail:", doctorEmail)
        print("New treamentPlan object:", newTreatmentPlan)
        response = treatmentPlans_dbtable.get_item(Key={'patientEmail': patientEmail})
        
        if "Item" not in response:
            print("Patient has no treatment plans. Initializing a list for them")
            newTreatmentPlan["doctorCreatedBy"] = doctorEmail
            treatmentPlanList = [newTreatmentPlan]
            
            # Create reminders in reminders table for this treatment plan by deconstructing each of the medicines and
            # pregenerate the scheduled times
            # {"TreatmentId":1, "Medicines":[{"MedicineName":"Aspirin","quantity":2, "type": "tablet", "location": "mouth", "frequency": "daily", "duration": 4}], "enabledReminder":True}
            
        else:
            print("Patient's current treatment plans:", response['Item']["treatmentPlan"])
            treatmentPlanList = response['Item']['treatmentPlan']
            # Add the new treatment plan to the current list
            treatmentPlanList = [item for item in treatmentPlanList if item["TreatmentId"] != newTreatmentPlan["TreatmentId"]] + [newTreatmentPlan]
        
        response = treatmentPlans_dbtable.put_item(
                Item={
                    "patientEmail": patientEmail,
                    "treatmentPlan": treatmentPlanList
                }
        )
        '''
        # response2 = dbtable.get_item(Key={'patientEmail': email})
        # print(response2['Item']['treatmentPlan'])
        
        # Create reminder records from the given Treatment plan
        insert_records = []
        # remindersTablePartitionKey = patientEmail + "_" + doctorEmail
        # Deconstruct the medicines
        medicines_string = ""
        for medicines_dict in newTreatmentPlan["Medicines"]:
            medicine_string = "_MedicineName_" + medicines_dict["MedicineName"] + "_quantity_" + \
                    str(medicines_dict["quantity"]) + "_type_" + medicines_dict["type"] + "_location_" + \
                    medicines_dict["location"] + "_frequency_" + medicines_dict["frequency"] + \
                    "_duration_" + str(medicines_dict["duration"])
            
            duration = medicines_dict["duration"]
            print(duration)
            frequency = medicines_dict["frequency"]
            curr_date_time = datetime.datetime.now()
            
            unique_medicine_reminder = patientEmail + "_" + doctorEmail + "_TreatmentId_" + \
                                                str(newTreatmentPlan["TreatmentId"]) + medicine_string
            print(unique_medicine_reminder)
            
            if frequency == "daily":
                # date_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S").split(" ")
                for i in range(int(duration)):
                    date, time = curr_date_time.strftime("%Y-%m-%d %H:%M:%S").split(" ")
                    record = {
                        "identify_medicine": unique_medicine_reminder + "_" + date + "_" + time,
                        "date": date,
                        "time": time,
                        "reminderFlag": False
                    }
                    insert_records.append(record)
                    curr_date_time = (curr_date_time + datetime.timedelta(days=1))
            elif frequency == "month":
                for i in range(int(duration)):
                    date, time = curr_date_time.strftime("%Y-%m-%d %H:%M:%S").split(" ")
                    record = {
                        "identify_medicine": unique_medicine_reminder + "_" + date + "_" + time,
                        "date": date,
                        "time": time,
                        "reminderFlag": False
                    }
                    insert_records.append(record)
                    curr_date_time = (curr_date_time + relativedelta(months=1))
            
        # Write the reminders to reminders table
        print(insert_records)
        with reminders_dbtable.batch_writer() as batch:
            for item in insert_records:
                batch.put_item(
                    Item=item
                )
        '''
        
        statusCode = response['ResponseMetadata']['HTTPStatusCode']
        returnMessage = "Successfully added treatmentPlan"
    
    except botocore.exceptions.ClientError as error:
        print("Exception occurred during Create Medicine")
        statusCode = error.response['Error']['Code']
        returnMessage = error.response['Error']['Message']
    
    return {
        'statusCode': statusCode,
        'body': json.dumps(returnMessage)
    }
