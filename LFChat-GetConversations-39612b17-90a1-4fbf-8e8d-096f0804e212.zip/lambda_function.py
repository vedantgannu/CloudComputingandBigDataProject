import json
import boto3
from botocore.exceptions import ClientError

db = boto3.resource('dynamodb')
conversationHoldersTable = db.Table("ConversationHolders")
conversationsTable = db.Table("Conversations")

def lambda_handler(event, context):
    
    print(event)
    
    try:
        body = json.loads(event['body'])
        senderEmail = body['senderEmail']
        # senderEmail = "doctor1@gmail.com"
        conversationHoldersDBResponse = lookup_data({'email': senderEmail}, conversationHoldersTable)
        conversationIds = conversationHoldersDBResponse["conversationIds"]
        print("conversationIds:",conversationIds)
        conversations = []
        for conversationId in conversationIds:
            conversations.append(lookup_data({'conversationId':conversationId}, conversationsTable))
        print("conversations:",conversations);
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': '*',
            },
            'body': json.dumps(conversations)
        }
    except Exception as e:
        # Handle any errors and return an error response
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': '*',
            },
            'body': f'Fail to get conversations: {str(e)}'
        }

def lookup_data(key, table):
    try:
        response = table.get_item(Key=key)
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        return response["Item"]
