import json
import boto3
import botocore


"""
Updates or replaces a treatment plan for patient
"""


# email = "patient1@gmail.com"
# treatmentPlan = {"TreatmentId":15, "Medicines":[{"MedicineName":"I made a change 3","quantity":2, "type": "tablet", "location": "mouth", "frequency": "daily", "duration": 4}], "enabledReminder":False}

def lambda_handler(event, context):
    # TODO implement
    
    email = event["email"]
    
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    dbtable = dynamodb.Table('treatmentPlans')
    
    try:
        print("Received Get Active Medicines request")
        print("patientEmail:", email)
        response = dbtable.get_item(Key={'patientEmail': email})
        
        if "Item" not in response:
            print("Patient has no treatment plans. Returning empty list")
            treatmentPlanList = []
        else:
            print("Patient's current treatment plans:", response['Item']["treatmentPlan"])
            treatmentPlanList = response['Item']['treatmentPlan']
        
        statusCode = response['ResponseMetadata']['HTTPStatusCode']
        
        return {
            'statusCode': statusCode,
            'body': json.dumps(treatmentPlanList, default=int)
        }
    
    except botocore.exceptions.ClientError as error:
        print("Exception occurred during Create Medicine")
        statusCode = error.response['Error']['Code']
        returnMessage = error.response['Error']['Message']
        return {
            'statusCode': statusCode,
            'body': json.dumps(returnMessage)
        }
