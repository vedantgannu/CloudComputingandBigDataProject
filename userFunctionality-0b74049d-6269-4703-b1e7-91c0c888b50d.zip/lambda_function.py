import json
import boto3
from datetime import datetime

dynamodb = boto3.resource('dynamodb') 

conversationHoldersTable = dynamodb.Table("ConversationHolders")
conversationsTable = dynamodb.Table("Conversations")

def lambda_handler(event, context):
    # TODO implement
    
    
    ''' expecting event to be in the form
    {
        'action': 'getProfile', 'login', 'setProfile', 'signUp','getContactorInfo', 'updatePatientList'
        'userName': str,
        'userType': str,
        'email': str,
        'password': str,
        'phone': str,
        'address': str,
        'insuranceCompany': str,
        'insuranceNumber': str,
        'company': str
    }'''
    
    action = event["action"]
    
    response = ''
    
    print(action)
    if action == 'getProfile':
        response = getProfile(event)
    elif action == 'login':
        response = login(event)
    elif action == 'setProfile':
        response = setProfile(event)
    elif action == 'getContactorInfo':
        response = getContactorInfo(event)
    elif action == 'updatePatientList':
        response = updatePatientList(event)
    else:
        response = signUp(event)
            
    
    
    return {
        'statusCode': 200,
        'body': response
    }

def getProfile(event):
    table = ''
    userType = event['userType']
    email = event['email']
    
    if userType == 'Patient':
        table = dynamodb.Table('patient')
    else:
        table = dynamodb.Table('doctor')
    
    response = table.get_item(
        Key={
            'email': email
        },
        TableName=userType.lower()
        )
    
    return response

def login(event):
    table = ''
    userType = event['userType']
    email = event['email']
    password = event['password']
    
    if userType == 'Patient':
        table = dynamodb.Table('patient')
    else:
        table = dynamodb.Table('doctor')
        
    # check if there is an entry in the table with email
    response = table.get_item(
        Key={
            'email': email
        },
        TableName=userType.lower(),
    )
    
    if response['Item']['userType'] == userType and response['Item']['password'] == password:
        return True,response["Item"]
    else:
        return False

def setProfile(event):
    # overrride the old profile with the new profile specified
    table = ''
    userType = event['userType']
    userName = event['userName']
    email = event['email']
    password = event['password']
    address = event['address']
    
    if userType == 'Patient':
        insurance = event['insuranceNumber']
        insuranceCompany = event['insuranceCompany']
        table = dynamodb.Table('patient')
    
        update = table.update_item(
            Key={
                'email': email
            },
            UpdateExpression = 'SET userType = :val1, userName = :val2, \
            password = :val3, address = :val4, insurance = :val5, \
            insuranceCompany = :val6',
            ExpressionAttributeValues = {
                ':val1': userType,
                ':val2': userName,
                ':val3': password,
                ':val4': address,
                ':val5': insurance,
                ':val6': insuranceCompany
            }
        )
        return update
    else:
        company = event['company']
        table = dynamodb.Table('doctor') 
        
        update = table.update_item(
            Key={
                    'email': email
            },
            UpdateExpression = 'SET userType = :val1, userName = :val2, \
            password = :val3, address = :val4, company = :val5',
            ExpressionAttributeValues = {
                ':val1': userType,
                ':val2': userName,
                ':val3': password,
                ':val4': address,
                ':val5': company
            }
        )
        return True

def signUp(event):
    table = ''
    userType = event['userType']
    userName = event['userName']
    email = event['email']
    password = event['password']
    address = event['address']
    
    
    
    if userType == 'Patient':
        insurance = event['insuranceCompany']
        insuranceCompany = event['insuranceNumber']
        table = dynamodb.Table('patient')
        # check if there is an entry in the table with email
        checkExisting = table.get_item(
            Key={
                'email': email
            },
            TableName=userType.lower(),
        )
    
        if 'Item' in checkExisting:
            return False
        else:
            response = table.put_item(
                Item={
                    'userType': userType,
                    'userName': userName,
                    'email': email,
                    'password': password,
                    'address': address,
                    'insurance': insurance,
                    'insuranceCompany': insuranceCompany
                },
                TableName=userType.lower(),
            )
            return True
    else:
        
        insertinserconversationHoldersDBResponse = insert_data([{"email":email, "conversationIds": []}], conversationHoldersTable)
        print("insertinserconversationHoldersDBResponse",insertinserconversationHoldersDBResponse)
        
        company = event['company']
        table = dynamodb.Table('doctor') 
        # check if there is an entry in the table with email
        checkExisting = table.get_item(
            Key={
                'email': email
            },
            TableName=userType.lower(),
        )
    
        if 'Item' in checkExisting:
            print("item in checkExisting")
            return False
        else:
            response = table.put_item(
                Item={
                    'userType': userType,
                    'userName': userName,
                    'email': email,
                    'password': password,
                    'address': address,
                    'company': company,
                    'patientList': []
                },
                TableName=userType.lower(),
            )
            return True
        
def getContactorInfo(event):
    # given an email return name of the user
    table = ""
    userType = event['userType']
    email = event['email']
    
    if userType == "Patient":
        table = dynamodb.Table('patient')
        response = table.get_item(
            Key={
                'email': email
            },
            TableName=userType.lower()
        )
        return response
    else:
        table = dynamodb.Table('doctor')
        response = table.get_item(
            Key={
                'email': email
            },
            TableName=userType.lower()
        )
    
        return response

def updatePatientList(event):
    table = dynamodb.Table('doctor')
    email = event['email']
    newPatient = event['patient']
    print("doctor email",email)
    print("newPatient:",newPatient)
    response = table.get_item(
            Key={
                'email': email
            }
        )
    patientTable = dynamodb.Table('patient')
    searchNewPatientResponse = patientTable.get_item(
            Key={
                'email': newPatient
            }
        )
    print("response:",response)
    print("searchNewPatientResponse",searchNewPatientResponse)
    patientList = response["Item"]["patientList"]
    print("patientList:",patientList)
    if "Item" not in searchNewPatientResponse or newPatient in patientList:
        print(False)
        return {"status":False}
    else:
        patientList.append(newPatient)
        print("updated patientList:",patientList)
        # patientList = event['patientList']
        update = table.update_item(
            Key={
                    'email': email
            },
            UpdateExpression = 'SET patientList = :val1',
            ExpressionAttributeValues = {
                ':val1': patientList
            }
        )
        print("update info:",update)
        
        timestamp = datetime.utcnow()
        timestamp_str = timestamp.isoformat() + 'Z'
        
        newConversation = [{
                        "members": [newPatient, email], 
                        "conversationId": newPatient+"-"+email, 
                        "createdAt": timestamp_str,
                        "updatedAt": timestamp_str,
                        "lastReadAt": [timestamp_str, timestamp_str],
                        "messages": []}]
        create = insert_data(newConversation, conversationsTable)
        print("create new conversation:",create);
        
        return {"status":True}
    
    
def insert_data(data_list, table):
    for data in data_list:
        response = table.put_item(Item=data)
    print('@insert_data: response', response)
    return response
